import './App.css';
import DisplayEmployee from './component/DisplayEmployee';
import AddEmployee from './component/AddEmployee';
import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import { Provider } from 'react-redux';
import { createStore } from "redux";
import axios from 'axios'
import { useEffect, useState } from "react";
import { variables } from './Variables';


// import { BrowserRouter, Route, Switch, NavLink , Routes } from 'react-router-dom';


function App() {

    const [apiData, setApiData] = useState([]);
    const [countries, setCountries] = useState([]);
    const [states, setStates] = useState([]);
    const [cities, setCities] = useState([]);

    useEffect(
        () => {
            axios.get(variables.Get_Employee_URL)
                .then(response => {
                    setApiData(response.data); console.log(apiData)
                });

            axios.get(variables.GetCounties)
                .then(response => {
                    setCountries(response.data);
                });

            axios.get(variables.GetStates)
                .then(response => {
                    setStates(response.data);
                });

            axios.get(variables.GetCities)
                .then(response => {
                    setCities(response.data);
                });
        },
        []
    );

    const store = createStore(() => ({
        apiData: apiData,
        countries: countries,
        states: states,
        cities: cities
    }));

    return (
        <BrowserRouter>
            <div className="App container">
                <h3 className="d-flex justify-content-center m-3">
                     Employee App
                </h3>

                <nav className="navbar navbar-expand-sm bg-light navbar-dark">
                    <ul className="navbar-nav mx-auto">
                        <li className="nav-item m-1">
                            <NavLink className="btn btn-light btn-outline-primary" to="/displayEmployees">
                                Employees
                            </NavLink>
                        </li>
                        <li className="nav-item m-1">
                            <NavLink className="btn btn-light btn-outline-primary" to="/employee">
                                AddEmployee
                            </NavLink>
                        </li>
                    </ul>
                </nav>
                <Provider store={store} > 
                <Routes>
                    <Route exact path='/' element={<DisplayEmployee />}></Route>
                    <Route exact path='/displayEmployees' element={<DisplayEmployee />}></Route> 
                    <Route exact path='/employee' element={<AddEmployee> </AddEmployee> }></Route> 
                    </Routes>
                  </Provider>
            </div>
        </BrowserRouter>
    );
}
export default App;