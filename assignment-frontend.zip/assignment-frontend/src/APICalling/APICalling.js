import './App.css';
import DisplayEmployee from './DisplayEmployee';
import { useDispatch, useSelector } from 'redux'
import axios from 'axios'
import { useEffect, useState } from "react";
import { variables } from './Variables';
import { createStore } from "redux";

const APICalling = () => {

    const [apiData, setApiData] = useState([]);
    const [countries, setCountries] = useState([]);
    const [states, setStates] = useState([]);
    const [cities, setCities] = useState([]);

    useEffect(
        () => {
            axios.get(variables.Get_Employee_URL)
                .then(response => {
                    setApiData(response.data); console.log(apiData)
                });

            axios.get(variables.GetCounties)
                .then(response => {
                    setCountries(response.data);
                });

            axios.get(variables.GetStates)
                .then(response => {
                    setStates(response.data);
                });

            axios.get(variables.GetCities)
                .then(response => {
                    setCities(response.data);
                });
        },
        []
    );

    const store = createStore(() => ({
        apiData: apiData, countries: countries, states: states, cities: cities
    }));



      return (
       <></>
       
    );
}

                   