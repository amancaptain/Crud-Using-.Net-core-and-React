import { useEffect, useState } from "react";
import axios from 'axios';
import { variables } from '../Variables'
import Swal from 'sweetalert2';
import validator from 'validator';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';


/*import DatePicker from 'react-datepicker';*/



const AddEmployee = (props) => {

    var formData = new FormData();
    const [image, setImage] = useState(null);

    var ageInYears = null;
    var fileSize = null;

     const [errors, setErrors] = useState({});
    

    const [apiData, setApiData] = useState({
        RowId : "100",
        EmployeeCode: "00100",
        FirstName: "",
        LastName: "",
        EmailAddress: "",
        MobileNumber: "",
        PanNumber: "",
        PassportNumber: "",
        Gender: "",
        IsActive: "Yes",
        DateOfBirth: null,
        DateOfJoinee: null,
        CreatedDate: new Date(),
        UpdatedDate: new Date(),
        IsDeteted: false,
        DeletedDate: new Date(),
        ProfileImage: null ,
        CountryId: 0,
        StateId: 0,
        CityId:0,
        Country: { CountryId: 0, CountryName: "" },
        State: { StateId: 0, StateName: ""},
        City: { CityId: 0, CityName: "" }
    });

   

    const [countries, setCountries] = useState([]);
    const [states, setStates] = useState([]);
    const [cities, setCities] = useState([]);

    const [addressData , setAddressData] = useState({ selectedCountry: "", selectedState: "", selectedCity: "" });


    useEffect(
        () => {
            axios.get(variables.GetCounties)
                .then(response => {
                    setCountries(response.data);
                });

            axios.get(variables.GetStates)
                .then(response => {
                    setStates(response.data); 
                });

            axios.get(variables.GetCities)
                .then(response => {
                    setCities(response.data);
                });
        },
        []
    );


    

    const handleChange = (event) => {
        const { name, value } = event.target  
        setApiData({ ...apiData, [name]: value })

        console.log(event.target.value)
 
    }

    const handleCountrySelect = (event) =>
    {
        var index = event.nativeEvent.target.selectedIndex;
        var countryname = event.nativeEvent.target[index].text
        setAddressData({ ...addressData, selectedCountry: event.target.value })
        const country = {};
        country.CountryId = event.target.value;
        country.CountryName = countryname
        setApiData({ ...apiData, Country: country, CountryId: country.CountryId })

        
        console.log(apiData.Country)
        console.log(addressData.selectedCountry)
    }

    const handleStateSelect = (event) => {
        var index = event.nativeEvent.target.selectedIndex;
        var statename = event.nativeEvent.target[index].text
        console.log(statename)
        setAddressData({ ...addressData, selectedState: event.target.value })
        const state = {};
        state.StateId = event.target.value;
        state.StateName = statename
        setApiData({ ...apiData, State: state, StateId: state.StateId })

    
        console.log(apiData.State)
    }

    const handleCitySelect = (event) => {
        var index = event.nativeEvent.target.selectedIndex;
        var cityname = event.nativeEvent.target[index].text
        setAddressData({ ...addressData, selectedCity: event.target.value })
        const city = {};
        city.CityId = event.target.value;
        city.CityName = cityname
        setApiData({ ...apiData, City: city, CityId: city.CityId })

    }

    const onFileChange = (e) => {
        const selectedFile = e.target.files[0];
        // setApiData({ ...apiData, ProfileImage: selectedFile })
        setImage(selectedFile)
        
    }

    const onIsActiveChange = (e) => {
        console.log(e.target.checked)
        setApiData({ ...apiData, IsActive: e.target.checked })

        formData.append("IsActive", e.target.checked)
        formData.append("IsDeleted", "False")
    }

    const savedata = (event) => {
        event.preventDefault();
        const panPattern = /^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/;
        const passportPattern = /^[A-Z0-9]{6,20}$/;
        const mobilePattern = /^[0-9]{10}$/;
        const currentDate = new Date();
        const selectedDate = new Date(apiData.DateOfBirth);
        const ageDifferenceInMilliseconds = currentDate - selectedDate;
        ageInYears = ageDifferenceInMilliseconds / (365.25 * 24 * 60 * 60 * 1000);
       //  fileSize = image["size"] / 1024;
        let errors = {}

        if (Boolean(apiData.FirstName.length == 0)) {
            errors["name"] = "Required";
            console.log(errors["name"])
        }

        else if (Boolean(apiData.FirstName.Length > 100)) {
            errors["nameValidation"] = "First Name should not be more than 100 characters";
        }

        if (Boolean(apiData.EmailAddress.length == 0))
        {
            errors["email"] = "Required";
        }

        else if (!validator.isEmail(apiData.EmailAddress)) {
            errors["emailValidation"] = "Email is not valid";
        }

        if (Boolean(apiData.MobileNumber.length == 0)) {
            errors["mobile"] = "Required";
        }

        else if (!mobilePattern.test(apiData.MobileNumber)) {
            errors["mobileValidation"] = "Mobile Number is not valid";
        }

        if (Boolean(apiData.PanNumber.length == 0)) {
            errors["pan"] = "Required";
        }

        else if (!panPattern.test(apiData.PanNumber)) {
            errors["panValidation"] = "Pan Number is not valid";
        }

        if (Boolean(apiData.PassportNumber.length == 0))
        {
            errors["passport"] = "Required";
        }
        
        else if (!passportPattern.test(apiData.PassportNumber)) {
            errors["passportValidation"] = "Passport Number is not valid";
        }

        if (apiData.DateOfBirth == null) {
            errors["dateOfBirth"] = "Required";
        }
        
        if (apiData.DateOfJoinee == null) {
            errors["dateOfJoinee"] = "Required";
        }

        else if (ageInYears < 18) {
            errors["dateOfBirthValidation"] = "Age must be more than 18 years";
        }
        
        else {

            formData.append("RowId", "0")
            formData.append("EmployeeCode", "001")
            formData.append("FirstName", apiData.FirstName)
            formData.append("LastName", apiData.LastName)
            formData.append("CountryId", apiData.CountryId)
            formData.append("StateId", apiData.StateId)
            formData.append("CityId", apiData.CityId)
            formData.append("EmailAddress", apiData.EmailAddress)
            formData.append("MobileNumber", apiData.MobileNumber)
            formData.append("PanNumber", apiData.PanNumber)
            formData.append("PassportNumber", apiData.PassportNumber)
            formData.append("Gender", apiData.Gender)
            formData.append("IsActive", apiData.IsActive)
            formData.append("DateOfBirth", apiData.DateOfBirth)
            formData.append("DateOfJoinee", apiData.DateOfJoinee)
            formData.append("CreatedDate", apiData.CreatedDate)
            formData.append("UpdatedDate", apiData.UpdatedDate)
            formData.append("IsDeleted", apiData.IsDeteted)
            formData.append("DeletedDate", apiData.DeletedDate)
            formData.append("ProfileImage", image)

            console.log(formData)
            console.log(apiData.Gender)

            //axios.post(variables.Add_String_Employee_URL, formData)
            //  .then(result => console.log(result))

            axios.post(
                variables.Add_String_Employee_URL, formData
            ).then(result => {

                console.log(result);
                Swal.fire({
                    title: 'Employee Added',
                    text: 'Employee Data added successfully',
                    icon: 'success',
                    showCancelButton: true,
                    confirmButtonText: 'OK',
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.reload();
                    }
                    else
                        window.location.reload();
                })

            }).catch(error => {
                // Handle errors, including 400 Bad Request
                if (error.response) {
                    // The request was made and the server responded with a status code
                    // that falls out of the range of 2xx (e.g., 400, 404, 500)
                    Swal.fire({
                        title: 'Employee Addition Failed',
                        text:  error.response.data ,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'OK',
                    }).then((result) => {
                        if (result.isConfirmed) {
                            console.log(result)  
                        }
                    })
                  //  alert(error.response.data);
                    console.error('Error response status:', error.response.status);
                    console.error('Error response data:', error.response.data);
                } else if (error.request) {
                    // The request was made but no response was received
                    console.error('No response received:', error.request);
                } else {
                    // Something happened in setting up the request that triggered an error
                    console.error('Request setup error:', error.message);
                }
                console.error('Error config:', error.config);
            })
        }
        setErrors(errors);

    }

   
    
    return (
        <>
            <h4>Add new employee</h4> 
            <br />
            <div class="row">
                <div class="mx-auto col-10 col-md-8 col-lg-6">

            <div className="form-group ">
                {/*<input id = "datepicker"class="datepicker" data-date-format="mm/dd/yyyy"/>*/}
                {/*<DatePicker*/}
                {/*    selected={apiData.DateOfBirth}*/}
                {/*    onChange={handleChange}*/}
                {/*    // dateFormat="dd-MM-yyyy" */}
                        {/*/>*/}

                        <form method="POST" onSubmit={savedata}>
                            <Row>
                                <Col className="col-md-4"> First Name <span className="text-danger"> * </span> </Col>

                                <Col className="col-md-3"> <input type="text" name="FirstName" value={apiData.FirstName} onChange={handleChange} /> </Col> 
                                { Boolean(apiData.FirstName.length == 0) && < span style={{ color: "red" }}>{errors["name"]}</span>}
                                { Boolean(apiData.FirstName.length > 100) && < span style={{ color: "red" }}>{errors["nameValidation"]}</span>}
                            </Row>
                            <br />
                            <Row>
                                <Col className="col-md-4">  Last Name  </Col>
                                <Col className="col-md-3"> <input type="text" name="LastName" value={apiData.LastName} onChange={handleChange} /> </Col>
                               <Col></Col>
                       
                            </Row>
                            <br />
                            <Row>
                                <Col className="col-md-4"> Email Address <span className="text-danger"> * </span>  </Col>
                                <Col className="col-md-3"> <input type="email" name="EmailAddress" onChange={handleChange} /> </Col>
                                {Boolean(apiData.EmailAddress.length == 0) && <span style={{ color: "red" }}>{errors["email"]}</span>}
                                {!validator.isEmail(apiData.EmailAddress) && <span style={{ color: "red" }}>{errors["emailValidation"]}</span>}
                            </Row>
                            <br />
                            <Row>
                                <Col className="col-md-4"> Mobile Number <span className="text-danger"> * </span>  </Col>
                                <Col className="col-md-3"> <input type="text" name="MobileNumber" onChange={handleChange} /> </Col>
                                {Boolean(apiData.MobileNumber.length == 0) && <span style={{ color: "red" }}>{errors["mobile"]}</span>}
                                {!(/^[0-9]{10}$/).test(apiData.MobileNumber) && <span style={{ color: "red" }}>{errors["mobileValidation"]}</span>}

                            </Row>
                            <br />
                            <Row>
                                <Col className="col-md-4"> Pan Number <span className="text-danger"> * </span></Col>
                                <Col className="col-md-3"> <input type="text" name="PanNumber" onChange={handleChange} /> </Col>
                                {Boolean(apiData.PanNumber.length == 0) && <span style={{ color: "red" }}>{errors["pan"]}</span>}
                                { !(/^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/).test(apiData.PanNumber) && <span style={{ color: "red" }}>{errors["panValidation"]}</span>}
                    </Row>  <br />
                            <Row>
                                <Col className="col-md-4"> Passpost Number <span className="text-danger"> * </span> </Col>

                                <Col className="col-md-3"> <input type="text" name="PassportNumber" onChange={handleChange} />  </Col>
                                {(Boolean(apiData.PassportNumber.length == 0)) && <span style={{ color: "red" }}>{errors["passport"]}</span>}
                                {!(/^[A-Z0-9]{6, 20}$/).test(apiData.PassportNumber) && <span style={{ color: "red" }}>{errors["passportValidation"]}</span>}

                    </Row>  <br />
                            <Row>
                                <Col className="col-md-4"> Date Of Birth <span className="text-danger"> * </span> </Col>
                                <Col className="col-md-3"> <input type="date" name="DateOfBirth" onChange={handleChange} /> </Col>
                                {(apiData.DateOfBirth == null) && <span style={{ color: "red" }}>{errors["dateOfBirth"]}</span>}
                                {(ageInYears < 18) && <span style={{ color: "red" }}>{errors["dateOfBirthValidation"]}</span>}
                    </Row>  <br />
                            <Row>
                                <Col className="col-md-4">  Date Of Joinee <span className="text-danger"> * </span> </Col>
                                <Col className="col-md-3"> <input type="date" name="DateOfJoinee" onChange={handleChange} />  </Col>
                                {(apiData.DateOfJoinee == null) && <span style={{ color: "red" }}>{errors["dateOfJoinee"]}</span>}

                    </Row>  <br />
                            <Row>

                                <Col className="col-md-4">  Country <span className="text-danger"> * </span> </Col>
                                <Col className="col-md-3"> <select value={addressData.selectedCountry} name="Country" id="country" onChange={handleCountrySelect} >
                                    <option value="0"> Select Country </option>

                                    {countries.map((country) => (
                                        <option key={country.countryId} value={country.countryId}>
                                            {country.countryName}
                                        </option>
                                    ))}
                                </select>
                                </Col>
                            </Row>  <br />
                            {addressData.selectedCountry && (
                                <Row>
                                    <Col className="col-md-4"> State </Col>
                                    <Col className="col-md-3">    <select value={addressData.selectedState} name="State" id="state" onChange={handleStateSelect} >
                                        <option value="199"> Select State </option>
                                        {states
                                            .filter((state) => state.countryId == apiData.CountryId)
                                            .map((state) => 
                                                <option key={state.stateId} value={state.stateId}>
                                                    {state.stateName}
                                                </option>
                                            )}
                                    </select>
                                    </Col>
                                   
                                </Row>)} <br />
                            {addressData.selectedState && (
                            <Row>
                                    <Col className="col-md-4">  City  </Col>
                                    <Col className="col-md-3"> <select value={addressData.selectedCity} name="City" id="city" onChange={handleCitySelect}>
                                    <option value="1999"> Select City </option>
                                        {cities
                                            .filter((city) => city.stateId == apiData.StateId)
                                            .map((city) => (
                                                <option key={city.cityId} value={city.cityId}>
                                                    {city.cityName}
                                                </option>
                                            ))}
                                </select>
                                    </Col>
                      
                    </Row> )} <br />
                            <Row>
                                <Col className="col-md-4">  ProfileImage  </Col>
                                <Col className="col-md-3"> <input type="file" id="img" name="img" accept="image/*" onChange={onFileChange} /> </Col>
                                {/*{(image == null) && <span style={{ color: "red" }}> {errors["image"]} </span>}*/}

                    </Row> <br />
                            <Row>

                                <Col className="col-md-4">   Gender <span className="text-danger"> * </span> </Col>
                                <Col className="col-md-4"> <label onChange={handleChange}> <input type="radio" value="Male" name="Gender" /> Male <input type="radio" value="Female" name="gender" /> Female </label > </Col>
                                
                    </Row> <br />
                            <Row>
                                <Col className="col-md-4">  IsActive <span className="text-danger"> * </span> </Col>
                                <Col className="col-md-3"> <input type="checkbox" id="active" name="active" value="IsActive" onChange={onIsActiveChange} /> Active </Col>
                                
                            </Row>  <br />
                            <div className="form-group"> <button className="btn btn-primary" type="button" onClick={savedata}>Save</button>  </div>
                    
                </form>
                    </div>
                </div></div>
        </>
    );

}
export default AddEmployee;