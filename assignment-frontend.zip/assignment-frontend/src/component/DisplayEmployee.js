﻿import { useEffect, useState } from "react";
import axios from 'axios';
import { variables } from '../Variables'
import Pagination from "../Pagination";
import { useSelector } from 'react-redux';
import DeleteEmployee from "./DeleteEmployee";
import EditEmployee from "./EditEmployee";

const DisplayEmployee = () => {

    const empData = useSelector(state => state.apiData);
    const countryList = useSelector(state => state.countries);
    const stateList = useSelector(state => state.states);
    const cityList = useSelector(state => state.cities);

    const [apiData, setApiData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(6); 
    const [countries, setCountries] = useState([]);
    const [states, setStates] = useState([]);
    const [cities, setCities] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredData, setFilteredData] = useState(null);
    const [accessor, setAccessor] = useState('asc');

    // const [sortedData, setSortedData] = useState(empData);

    useEffect(
        () => {
            axios.get(variables.Get_Employee_URL)
                .then(response => {
                    setApiData(response.data); console.log(apiData)
                });

            axios.get(variables.GetCounties)
                .then(response => {
                    setCountries(response.data);
                });

            axios.get(variables.GetStates)
                .then(response => {
                    setStates(response.data);
                });

            axios.get(variables.GetCities)
                .then(response => {
                    setCities(response.data);
                });
        },
        []
    );

    

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = apiData.slice(indexOfFirstItem, indexOfLastItem);
    

    const handleSorting = (sortField, sortOrder) => {
        if (sortField) {
            const sorted = [...apiData].sort((a, b) => {
                return (
                    a[sortField].toString().localeCompare(b[sortField].toString(), "en", {
                        numeric: true,
                    }) * (sortOrder === "asc" ? 1 : -1)
                );
            });
            setApiData(sorted);
            if (sortOrder == 'asc')
                setAccessor('desc')
            else
                setAccessor('asc')
        }
    };


    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };


    const handleInputChange = (e) => {
        setSearchQuery(e.target.value);
        if (e.target.value == "")
            window.location.reload()  
    };
    
    const handleSearch = () => {
      const data =   apiData.filter((item) =>
          item.emailAddress.toLowerCase().includes(searchQuery.toLowerCase()))

        setFilteredData(data)
    };


    var tablerows = filteredData ?
        filteredData.map(obj => {
            return (
                <tr key={obj.emailAddress}>
                    <td>{obj.emailAddress}</td>
                    <td>{obj.countryName}</td>
                    <td>{obj.stateName}</td>
                    <td>{obj.cityName}</td>
                    <td>{obj.panNumber}</td>
                    <td>{obj.passportNumber}</td>
                    <td>{obj.gender}</td>
                    <td>{obj.isActive ? "True" : "False"}</td>
                    <td> <img src={require('../Img.jpg')} width="50" height="50" alt="Example" /></td>
                    <td>
                        <EditEmployee empObj={obj} countries={countries} states={states} cities={cities} />

                        <DeleteEmployee email={obj.emailAddress} />
                    </td>

                </tr>
            );
        })
        : currentItems.map(obj => {
            return (

                <tr key={obj.emailAddress}>
                    <td>{obj.emailAddress}</td>
                    <td>{obj.countryName}</td>
                    <td>{obj.stateName}</td>
                    <td>{obj.cityName}</td>
                    <td>{obj.panNumber}</td>
                    <td>{obj.passportNumber}</td>
                    <td>{obj.gender}</td>
                    <td>{obj.isActive ? "True" : "False"}</td>
                    <td> <img src={require('../Img.jpg')} width="50" height="50" alt="Example" /></td>
                    <td>
                        <EditEmployee empObj={obj} countries={countries} states={states} cities={cities} />
                        <DeleteEmployee email={obj.emailAddress} />
                    </td>

                </tr>
            );
        });
    

    return (
        <>
            <br /><br />
            <input
                type="text"
                placeholder="Search by email"
                value={searchQuery}
                onChange={handleInputChange}
            />
            <button onClick={handleSearch}>Search</button>
            <br/>
            <br/>
            <div className = "table-responsive"> 
            <table className="table table-bordered table-success" id="EmployeesTable">
                    <tr>
                        <th onClick={() => handleSorting('emailAddress', accessor)} >
                            Email
                            {/*{ accessor == 'asc'*/}
                            {/*    ? <span>▼</span>*/}
                            {/*    : <span>▲</span>*/}
                            {/*}*/}
                    </th>
                        <th onClick={() => handleSorting('countryName', accessor)}>
                        Country
                    </th>
                        <th onClick={() => handleSorting('stateName', accessor)}>
                        State
                    </th>
                        <th onClick={() => handleSorting('cityName', accessor)}>
                        City
                    </th>
                        <th >
                        Pan No
                    </th>
                        <th >
                        Passport No
                    </th>
                    <th>
                        Gender
                    </th>
                    <th>
                        IsActive
                    </th>
                    <th>
                        Profile Image
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
                {tablerows}
                </table>
                <Pagination
                    itemsPerPage={itemsPerPage}
                    totalItems={apiData.length}
                    paginate={paginate}
                    currentPage={currentPage}
                />
            </div>
            
            
        </>
    );

}
export default DisplayEmployee;