﻿import axios from 'axios';
import Swal from 'sweetalert2';
import { Archive } from 'tabler-icons-react';


const DeleteEmployee = (props) => {

    console.log(props)
    const deleteClick = (email, e) => {
        console.log(email)
        Swal.fire({
            title: 'Delete Employee',
            text: 'Are you are want to delete this employee data ?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
        }).then((result) => {
            if (result.isConfirmed) {
                // Swal.fire('You clicked Yes!', 'You confirmed the action', 'success');
                axios.delete(`https://localhost:7113/api/Employee/DeleteEmployee`, { params: { email: email } })
                    .then(response => {
                        console.log(response)
                        window.location.reload();
                    });
            }
            else if (result.isDismissed === Swal.DismissReason.cancel) {
                Swal.fire('You clicked No!', 'You canceled the action', 'error');
            }
        }).catch(error => {
            if (error.response) {
                console.log(error.message)
            }
        });
    }

    return (
         <button className = "btn btn-danger" type = "button" onClick = {(e) => deleteClick(props.email, e)} > <Archive /> </button >
    );

}

export default DeleteEmployee;