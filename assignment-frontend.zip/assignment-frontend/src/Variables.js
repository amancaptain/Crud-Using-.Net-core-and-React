export const variables = {
    Get_Employee_URL: "https://localhost:7113/api/Employee/GetEmployee",
    Add_Employee_URL: "https://localhost:7113/api/Employee/AddEmployee",
    Add_String_Employee_URL : "https://localhost:7113/api/Employee/AddEmployeeData",
    Update_Employee_URL: "https://localhost:7113/api/Employee/UpdateEmployee",
    Update_Employee_Data_URL: "https://localhost:7113/api/Employee/UpdateEmployeeData",
    Delete_Employee_URL: "https://localhost:7113/api/Employee/DeleteEmployee",
    GetCounties: "https://localhost:7113/api/Employee/GetCountries",
    GetStates: "https://localhost:7113/api/Employee/GetStates",
    GetCities: "https://localhost:7113/api/Employee/GetCities"
}