﻿import axios from 'axios';
import Swal from 'sweetalert2';
import { Edit } from 'tabler-icons-react';
import { useState } from "react";
import validator from 'validator';
import { variables } from '../Variables'
import { Modal, Button } from 'react-bootstrap';
import dayjs from "dayjs";


const EditEmployee = (props) => {

    const [showModal, setShowModal] = useState(false);
    const [addressData, setAddressData] = useState({ selectedCountry: "", selectedState: "", selectedCity: "" });
    const [firstNameErrorMessage, setFirstNameErrorMessage] = useState("");
    const [emailErrorMessage, setEmailErrorMessage] = useState("");
    const [mobileErrorMessage, setMobileErrorMessage] = useState("");
    const [panErrorMessage, setPanErrorMessage] = useState("");
    const [passportErrorMessage, setPassportErrorMessage] = useState("");
    const [dateOfBirthErrorMessage, setDateOfBirthErrorMessage] = useState("");
    var ageInYears = null;
    var formData = new FormData();
    const [image, setImage] = useState(null);
    const [updatedApiData, setUpdatedApiData] = useState({
        RowId: "",
        EmployeeCode: "",
        FirstName: "",
        LastName: "",
        EmailAddress: "",
        MobileNumber: "",
        PanNumber: "",
        PassportNumber: "",
        Gender: "",
        IsActive: "Yes",
        DateOfBirth: new Date(),
        DateOfJoinee: new Date(),
        CreatedDate: new Date(),
        UpdatedDate: new Date(),
        IsDeteted: false,
        DeletedDate: new Date(),
        ProfileImage: null,
        CountryId: 0,
        StateId: 0,
        CityId: 0,
        Country: { CountryId: 0, CountryName: "" },
        State: { StateId: 0, StateName: "" },
        City: { CityId: 0, CityName: "" }
    });

    const handlleOpen = (e, obj) => {

        setShowModal(true)
        setAddressData({
            selectedCountry: obj.countryName,
            selectedState: obj.stateName,
            selectedCity: obj.cityName
        })
        console.log(addressData)
        setUpdatedApiData(
            {
                ...updatedApiData,
                RowId: obj.rowId,
                EmployeeCode: obj.employeeCode,
                FirstName: obj.firstName,
                LastName: obj.lastName,
                EmailAddress: obj.emailAddress,
                MobileNumber: obj.mobileNumber,
                CountryId: obj.countryId,
                CountryName: obj.countryName,
                StateId: obj.stateId,
                StateName: obj.stateName,
                CityId: obj.cityId,
                CityName: obj.cityName,
                PanNumber: obj.panNumber,
                PassportNumber: obj.passportNumber,
                Gender: obj.gender,
                IsActive: obj.isActive,
                ProfileImage: obj.profileImage,
                DateOfJoinee: obj.dateOfJoinee,
                DateOfBirth: obj.dateOfBirth
            })
        console.log(updatedApiData)
    }
    const handleClose = () => setShowModal(false);

    const handleChange = (event) => {
        const { name, value } = event.target
        setUpdatedApiData({ ...updatedApiData, [name]: value })

        console.log(event.target.value)
    }

    const handleCountrySelect = (event) => {
        var index = event.nativeEvent.target.selectedIndex;
        var countryname = event.nativeEvent.target[index].text
        setAddressData({ ...addressData, selectedCountry: event.target.value })
        const country = {};
        country.CountryId = event.target.value;
        country.CountryName = countryname
        setUpdatedApiData({ ...updatedApiData, Country: country, CountryId: country.CountryId })

    }

    const handleStateSelect = (event) => {
        var index = event.nativeEvent.target.selectedIndex;
        var statename = event.nativeEvent.target[index].text
        console.log(statename)
        setAddressData({ ...addressData, selectedState: event.target.value })
        const state = {};
        state.StateId = event.target.value;
        state.StateName = statename
        setUpdatedApiData({ ...updatedApiData, State: state, StateId: state.StateId })
    }

    const handleCitySelect = (event) => {
        var index = event.nativeEvent.target.selectedIndex;
        var cityname = event.nativeEvent.target[index].text
        setAddressData({ ...addressData, selectedCity: event.target.value })
        const city = {};
        city.CityId = event.target.value;
        city.CityName = cityname
        setUpdatedApiData({ ...updatedApiData, City: city, CityId: city.CityId })

    }

    const onFileChange = (e) => {
        setImage(e.target.files[0])
        console.log(e.target.files[0])
    }

    const onIsActiveChange = (e) => {
        console.log(e.target.checked)
        setUpdatedApiData({ ...updatedApiData, IsActive: e.target.checked })

        formData.append("IsActive", e.target.checked)
        formData.append("IsDeleted", "False")
    }

    const updateClick = (e) => {
        console.log()
        e.preventDefault();
        setShowModal(true);


        const panPattern = /^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/;
        const passportPattern = /^[A-Z0-9]{6,20}$/;
        const mobilePattern = /^[0-9]{10}$/;
        const currentDate = new Date();
        const selectedDate = new Date(updatedApiData.DateOfBirth);
        const ageDifferenceInMilliseconds = currentDate - selectedDate;
        ageInYears = ageDifferenceInMilliseconds / (365.25 * 24 * 60 * 60 * 1000);

        if (updatedApiData.FirstName == "") {
            setFirstNameErrorMessage("First Name Required")
        }

        else if (Boolean(updatedApiData.FirstName.Length > 100)) {
            setFirstNameErrorMessage("First Name should not be more than 100 characters");
        }

        else if (Boolean(updatedApiData.EmailAddress.length == 0)) {
            setEmailErrorMessage("Email Address required")
        }

        else if (!validator.isEmail(updatedApiData.EmailAddress)) {
            setEmailErrorMessage("Email is not valid");
        }

        else if (Boolean(updatedApiData.MobileNumber.length == 0)) {
            setMobileErrorMessage("Mobile Number required")
        }

        else if (!mobilePattern.test(updatedApiData.MobileNumber)) {
            setMobileErrorMessage("Mobile Number is not valid")
        }

        else if (Boolean(updatedApiData.PanNumber.length == 0)) {
            setPanErrorMessage('PAN number Required');
        }

        else if (!panPattern.test(updatedApiData.PanNumber)) {
            setPanErrorMessage('PAN number is not valid.');
        }

        else if (Boolean(updatedApiData.PassportNumber.length == 0)) {
            setPassportErrorMessage("Passport Number Required")
        }
        else if (!passportPattern.test(updatedApiData.PassportNumber)) {
            setPassportErrorMessage('Passport number is not valid.');
        }
        //else if (updatedApiData.DateOfBirth === new Date()) {
        //    setDateOfBirthErrorMessage('Date of birth required');
        //}
        else if (ageInYears < 18) {
            setDateOfBirthErrorMessage('Age must be more than 18 years');
            console.log(ageInYears)
        }

        else {
            formData.append("RowId", updatedApiData.RowId)
            formData.append("EmployeeCode", updatedApiData.EmployeeCode)
            formData.append("FirstName", updatedApiData.FirstName)
            formData.append("LastName", updatedApiData.LastName)
            formData.append("CountryId", updatedApiData.CountryId)
            formData.append("StateId", updatedApiData.StateId)
            formData.append("CityId", updatedApiData.CityId)
            formData.append("EmailAddress", updatedApiData.EmailAddress)
            formData.append("MobileNumber", updatedApiData.MobileNumber)
            formData.append("PanNumber", updatedApiData.PanNumber)
            formData.append("PassportNumber", updatedApiData.PassportNumber)
            formData.append("Gender", updatedApiData.Gender)
            formData.append("IsActive", updatedApiData.IsActive)
            formData.append("DateOfBirth", updatedApiData.DateOfBirth)
            formData.append("DateOfJoinee", updatedApiData.DateOfJoinee)
            formData.append("CreatedDate", updatedApiData.CreatedDate)
            formData.append("UpdatedDate", updatedApiData.UpdatedDate)
            formData.append("IsDeleted", updatedApiData.IsDeteted)
            formData.append("DeletedDate", updatedApiData.DeletedDate)
            formData.append("ProfileImage", image)

            axios.put(variables.Update_Employee_Data_URL, formData)
                .then(response => {
                    console.log(response)
                    if (response.status == 200) {
                        setShowModal(false)
                        Swal.fire({
                            title: 'Employee Edit',
                            text: 'Employee edited successfully',
                            icon: 'success',
                            showCancelButton: true,
                            confirmButtonText: 'OK',
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.reload();
                            }
                            else
                                window.location.reload();
                        })
                    }
                }).catch(error => {
                    // Handle errors, including 400 Bad Request
                    if (error.response) {
                        // The request was made and the server responded with a status code
                        // that falls out of the range of 2xx (e.g., 400, 404, 500)
                        Swal.fire({
                            title: 'Employee Updation Failed',
                            text: error.response.data,
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: 'OK',
                        }).then((result) => {
                            if (result.isConfirmed) {
                                console.log(result)
                            }
                        })
                        //  alert(error.response.data);
                        console.error('Error response status:', error.response.status);
                        console.error('Error response data:', error.response.data);
                    } else if (error.request) {
                        // The request was made but no response was received
                        console.error('No response received:', error.request);
                    } else {
                        // Something happened in setting up the request that triggered an error
                        console.error('Request setup error:', error.message);
                    }
                    console.error('Error config:', error.config);
                })
        }

    }
    

    return (
        <>
            <button className="btn btn-primary" type="button" onClick={(e) => handlleOpen(e, props.empObj)}><Edit /></button>
            <Modal show={showModal} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Update Emloyee</Modal.Title>
                </Modal.Header>
                <Modal.Body closeButton>


                    <form method="POST">
                        <div className=" row">
                            <div className="col-md-3"> First Name </div>
                            <div className="col-md-3">  <input type="text" name="FirstName" value={updatedApiData.FirstName} onChange={handleChange} required /> </div>
                            {(Boolean(updatedApiData.FirstName.length == 0) || Boolean(updatedApiData.FirstName.length > 100)) && <div className="firstNameError text-danger"> {firstNameErrorMessage} </div>}
                        </div>
                        <br />
                        <div className=" row">
                            <div className="col-md-3">  Last Name  </div>
                            <div className="col-md-3"> <input type="text" name="LastName" value={updatedApiData.LastName} onChange={handleChange} /> </div>
                        </div>
                        <br />
                        <div className=" row">
                            <div className="col-md-3"> Email Address   </div>
                            <div className="col-md-3"> <input type="email" value={updatedApiData.EmailAddress} name="EmailAddress" onChange={handleChange} /> </div>
                            {(!validator.isEmail(updatedApiData.EmailAddress)) && <div className=" emailError text-danger"> {emailErrorMessage} </div>}

                        </div>
                        <br />
                        <div className=" row">
                            <div className="col-md-3"> Mobile Number   </div>
                            <div className="col-md-3"> <input type="text" value={updatedApiData.MobileNumber} name="MobileNumber" onChange={handleChange} /> </div>
                            {(!(/^[0-9]{10}$/).test(updatedApiData.MobileNumber)) && <div className="mobileError text-danger"> {mobileErrorMessage} </div>}
                        </div>
                        <br />
                        <div className=" row">
                            <div className="col-md-3"> Pan Number </div>
                            <div className="col-md-3"> <input type="text" value={updatedApiData.PanNumber} name="PanNumber" onChange={handleChange} /> </div>
                            {(!(/^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/).test(updatedApiData.PanNumber)) && <div className="panError text-danger"> {panErrorMessage} </div>}

                        </div>  <br />
                        <div className=" row">
                            <div className="col-md-3"> Passpost Number  </div>
                            <div className="col-md-3"> <input type="text" name="PassportNumber" value={updatedApiData.PassportNumber} onChange={handleChange} />  </div>
                            {(!(/^[A-Z0-9]{6, 20}$/).test(updatedApiData.PassportNumber)) && <div className="passportError text-danger"> {passportErrorMessage} </div>}

                        </div>  <br />
                        <div className=" row">
                            <div className="col-md-3"> Date Of Birth  </div>
                            <div className="col-md-3"> <input type="date" id="dateOfBirth" defaultValue={dayjs(updatedApiData.DateOfBirth).format('YYYY-MM-DD')} /*value={format(new Date(updatedApiData.DateOfBirth) 'yyyy-mm-dd')} */ name="DateOfBirth" onChange={handleChange} /> </div>
                            {(ageInYears < 18) && <div className="dateOfBirthError text-danger"> {dateOfBirthErrorMessage} </div>}

                        </div>  <br />
                        <div className=" row">
                            <div className="col-md-3">  Date Of Joinee </div>
                            <div className="col-md-3"> <input type="date" defaultValue={dayjs(updatedApiData.DateOfJoinee).format('YYYY-MM-DD')} name="DateOfJoinee" onChange={handleChange} />  </div>
                        </div>  <br />
                        <div className=" row">

                            <div className="col-md-3">  Country </div>
                            <div className="col-md-3"> <select value={addressData.selectedCountry} name="Country" id="country" onChange={handleCountrySelect} >
                                <option value="0"> {addressData.selectedCountry} </option>

                                {props.countries.map((country) => (
                                    <option key={country.countryId} value={country.countryId} >
                                        {country.countryName}
                                    </option>
                                ))}
                            </select>
                            </div>
                        </div>  <br />


                        {addressData.selectedCountry && (
                            <div className=" row">
                                <div className="col-md-3"> State </div>
                                <div className="col-md-3">    <select value={addressData.selectedState} name="State" id="state" onChange={handleStateSelect} >
                                    <option value="199"> {addressData.selectedState} </option>

                                    {props.states
                                        .filter((state) => state.countryId == updatedApiData.CountryId)
                                        .map((state) =>
                                            <option key={state.stateId} value={state.stateId}>
                                                {state.stateName}
                                            </option>
                                        )}
                                </select> </div> </div>
                        )}
                        <br />
                        {addressData.selectedState && (
                            <div className=" row">
                                <div className="col-md-3">  City  </div>
                                <div className="col-md-3"> <select value={addressData.selectedCity} name="City" id="city" onChange={handleCitySelect}>
                                    <option value="1999"> {addressData.selectedCity} </option>
                                    {props.cities
                                        .filter((city) => city.stateId == updatedApiData.StateId)
                                        .map((city) => (
                                            <option key={city.cityId} value={city.cityId}>
                                                {city.cityName}
                                            </option>
                                        ))}
                                </select>
                                </div>
                            </div>)} <br />
                        <div className=" row">
                            <div className="col-md-3">  ProfileImage  </div>
                            <div className="col-md-3"> <input type="file" id="img" name="img" accept="image/*" onChange={onFileChange} /> </div>
                        </div> <br />
                        <div className=" row">

                            <div className="col-md-3">   Gender  </div>
                            <div className="col-md-4"> <label onChange={handleChange}> <input type="radio" value="Male" defaultChecked={updatedApiData.Gender === 'Male'} name="Gender" /> Male <input type="radio" value="Female" defaultChecked={updatedApiData.Gender === 'Female'} name="gender" /> Female </label > </div>
                        </div> <br />
                        <div className=" row">
                            <div className="col-md-3">  IsActive </div>
                            <div className="col-md-3"> <input type="checkbox" id="active" name="active" value={updatedApiData.IsActive} checked={updatedApiData.IsActive} onChange={onIsActiveChange} /> Active </div>
                            <br />
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="contained" color="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="contained" color="primary" onClick={updateClick}>
                        Save Changes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default EditEmployee;